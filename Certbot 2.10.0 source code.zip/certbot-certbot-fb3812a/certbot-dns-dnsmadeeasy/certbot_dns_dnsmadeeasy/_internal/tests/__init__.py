"""certbot-dns-dnsmadeeasy tests"""
