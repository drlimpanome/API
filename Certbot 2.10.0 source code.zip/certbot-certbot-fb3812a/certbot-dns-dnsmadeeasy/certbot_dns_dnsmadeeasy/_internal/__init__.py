"""Internal implementation of `~certbot_dns_dnsmadeeasy.dns_dnsmadeeasy` plugin."""
