"""Internal implementation of `~certbot_dns_google.dns_google` plugin."""
