"""Certbot compatibility test"""
