"""Internal implementation of `~certbot_dns_dnsimple.dns_dnsimple` plugin."""
